#ifndef    types_h
#define    types_h

//#define REAL_IS_FLOAT
//typedef float real;

#define REAL_IS_DOUBLE
typedef double real;

//#define REAL_IS_LONG_DOUBLE
//typedef long double real;

#endif  // types_h
